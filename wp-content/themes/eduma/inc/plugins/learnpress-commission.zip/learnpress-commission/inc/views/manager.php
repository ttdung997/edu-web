<?php

$lp_commission_table = new LP_Commission_List_Table();
$lp_commission_table->display();