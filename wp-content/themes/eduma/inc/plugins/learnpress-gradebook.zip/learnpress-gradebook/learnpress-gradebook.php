<?php
/*
Plugin Name: LearnPress - Gradebook
Plugin URI: http://thimpress.com/learnpress
Description: Adding Course Gradebook for LearnPress
Author: ThimPress
Version: 2.0.1
Author URI: http://thimpress.com
Tags: learnpress
Text Domain: learnpress
Domain Path: /languages/
*/
if ( !defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

define( 'LP_GRADEBOOK_PATH', dirname( __FILE__ ) );
define( 'LP_GRADEBOOK_THEME_TMPL', get_template_directory() . '/learnpress/addons/gradebook' );
define( 'LP_GRADEBOOK_TMPL', LP_GRADEBOOK_PATH . '/templates' );
define('LP_GRADEBOOK_VER', '2.0.1');
define('LP_GRADEBOOK_REQUIRE_VER', '2.0');

/**
 * Class LP_GradeBook
 */
class LP_GradeBook {
	/**
	 * @var null
	 */
	protected static $_instance = null;

	/**
	 * LP_GradeBook constructor.
	 */
	function __construct() {
		require_once LP_GRADEBOOK_PATH . '/inc/functions.php';
		$this->_init_hooks();

	}

	function export( $course_id, $args = null ) {
		$args     = wp_parse_args(
			$args,
			array(
				'type'  => 'csv',
				'from'  => '',
				'to'    => '',
				's'     => '',
				'count' => false,
				'limit' => - 1
			)
		);
		$filename = sanitize_title( get_the_title( $course_id ) ) . '-gradebook';

		$course        = LP_Course::get_course( $course_id );
		$course_result = get_post_meta( $course_id, '_lp_course_result', true );
		switch ( $course_result ) {
			case 'evaluate_lesson':
				$users = learn_press_gradebook_get_lessons( $course_id, $args );
				$items = $course->get_lessons();
				break;
			case 'evaluate_final_quiz':
				$users = learn_press_gradebook_get_quizzes( $course_id, $args );
				$items = $course->get_quizzes();
			case 'evaluate_quizzes':
				$users = learn_press_gradebook_get_quizzes( $course_id, $args );
				$items = $course->get_quizzes();
				break;
		}

		$data = array(
			array(
				__( 'User ID', 'learnpress' ),
				__( 'User login', 'learnpress' ),
				__( 'User email', 'learnpress' ),
				__( 'User display name', 'learnpress' )
			)
		);
		if ( $items ) foreach ( $items as $item ) {
			$title = get_the_title( $item->ID );
			if ( $item->ID == $course->final_quiz ) {
				$title = sprintf( __( '%s (Final)', 'learnpress' ), $title );
			}
			$data[0][] = $title;
		}
		$data[0][] = __( 'Average', 'learnpress' );
		$data[0][] = __( 'Status', 'learnpress' );
		if ( $users ) {
			foreach ( $users as $user ) {
				$row    = array();
				$row[]  = $user['user']['id'];
				$row[]  = $user['user']['user_login'];
				$row[]  = $user['user']['user_email'];
				$row[]  = $user['user']['display_name'];
				$result = 0;
				if ( $items ) foreach ( $items as $item ) {
					if ( !empty( $user['items'][$item->ID] ) ) {
						if ( $course_result == 'evaluate_final_quiz' ) {
							//if($item->ID == $course->final_quiz ) {
							$_user = learn_press_get_user( $user['user']['id'] );
							if ( $_user && $results = $_user->get_quiz_results( $item->ID ) ) {
								$result = $results->results['mark_percent'];
							}
							//}
							$result_text = $user['items'][$item->ID]['status'] == 'completed' ? __( '%s Completed', 'learnpress' ) : __( '%s In Progress', 'learnpress' );
							$row[]       = sprintf( $result_text, $result . '%' );
						} else {
							$row[] = $user['items'][$item->ID]['status'] == 'completed' ? __( 'Completed', 'learnpress' ) : __( 'In Progress', 'learnpress' );
						}
					} else {
						$row[] = '-';
					}
				}
				if ( $course_result == 'evaluate_lesson' ) {
					$result = round( $user['items_completed'] / sizeof( $items ) * 100, 2 );
				}
				$row[]  = $result . '%';
				$row[]  = $user['status'] == 'completed' ? __( 'Completed', 'learnpress' ) : __( 'In Progress', 'learnpress' );
				$data[] = $row;
			}
		}

		if ( strtolower( $args['type'] ) == 'csv' ) {
			header( "Cache-Control: public" );
			header( "Content-Type: application/octet-stream" );
			header( "Content-Type: text/csv; charset=utf-8" );
			header( 'Content-Disposition: attachment; filename=' . $filename . '.csv' );
			header( 'Pragma: no-cache' );
			foreach ( $data as $k => $row ) {
				echo $k ? "\n" : '';
				echo join( ',', $row );
			}
		}
		exit();
	}

	private function _init_hooks() {
		add_filter( 'manage_lp_course_posts_columns', array( $this, 'manage_course_posts_columns' ) );
		add_action( 'manage_lp_course_posts_custom_column', array( $this, 'manage_course_post_column' ), 10, 2 );
		add_action( 'admin_menu', array( $this, 'register_gradebook_page' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'scripts' ) );
		add_action( 'wp_enqueue_scripts', array( $this, 'scripts' ) );
		add_action( 'init', array( $this, 'process' ) );
		add_action( 'admin_head', array( $this, 'admin_head' ) );
		add_filter( 'learn_press_user_profile_tabs', array( $this, 'gradebook_tab' ), 105, 2 );
		add_filter( 'learn_press_profile_tab_endpoints', array( $this, 'profile_tab_endpoints' ) );
	}

	function gradebook_tab( $tabs, $user ) {
		$tabs[$this->get_tab_slug()] = array(
			'title'    => __( 'Gradebook', 'learnpress' ),
			'callback' => array( $this, 'gradebook_tab_content' )
		);
		return $tabs;
	}

	function gradebook_tab_content( $tab, $tabs, $user ) {
		learn_press_gradebook_template(
			'profile/gradebook.php', array(
				'tab'  => $tab,
				'tabs' => $tabs,
				'user' => $user
			)
		);
	}

	function profile_tab_endpoints( $endpoints ) {
		$endpoints[] = $this->get_tab_slug();
		return $endpoints;
	}

	function get_tab_slug() {
		return 'gradebook';
	}

	function process() {
		$course_id = !empty( $_REQUEST['course_id'] ) ? $_REQUEST['course_id'] : 0;
		if ( learn_press_gradebook_verify_nonce( $course_id ) ) {
			if ( !empty( $_REQUEST['export'] ) ) {
				$this->export( $course_id,
					array(
						'type' => learn_press_get_request( 'export' ),
						's'    => learn_press_get_request( 's' ),
						'from' => learn_press_get_request( 'date-from' ),
						'to'   => learn_press_get_request( 'date-to' )
					)
				);
			}
		}
	}

	function scripts() {
		wp_enqueue_style( 'learn-press-gradebook', plugins_url( '/', __FILE__ ) . 'assets/gradebook.css' );
		if ( is_admin() ) {
			wp_enqueue_script( 'learn-press-gradebook', plugins_url( '/', __FILE__ ) . 'assets/gradebook.js', array( 'jquery', 'jquery-ui-datepicker' ) );
		}
	}

	function admin_head() {
	}

	/**
	 * The gradebook page
	 *
	 * @return mix
	 */
	function register_gradebook_page() {
		$hook = add_submenu_page(
			'',
			__( 'Course Gradebook', 'learnpress' ),
			'',
			'edit_published_lp_courses',
			'course-gradebook',
			array( $this, 'gradebook_page' )
		);
		add_action( "load-$hook", array( $this, 'add_options' ) );
	}

	function add_options() {
		$args = array(
			'label'   => __( 'Number of items per page', 'learnpress' ),
			'default' => 20,
			'option'  => 'users_per_page'
		);
		add_screen_option( 'per_page', $args );
	}

	function gradebook_page() {
		$course_id = !empty( $_REQUEST['course_id'] ) ? $_REQUEST['course_id'] : 0;

		global $post;
		$post = get_post( $course_id );
		setup_postdata( $post );
		if ( !class_exists( 'WP_List_Table' ) ) {
			require_once ABSPATH . 'wp-admin/includes/class-wp-list-table.php';
		}
		require_once LP_GRADEBOOK_PATH . '/inc/admin/class-gradebook-list-table.php';
		require LP_GRADEBOOK_PATH . '/inc/admin/gradebook.php';
		wp_reset_postdata();
	}

	/**
	 * Add gradebook column to course page in admin
	 *
	 * @param  array $column
	 *
	 * @return array
	 */
	function manage_course_posts_columns( $column ) {
		$date                = !empty( $column['date'] ) ? $column['date'] : null;
		$column['gradebook'] = __( 'Gradebook', 'learnpress' );
		if ( $date ) {
			unset( $column['date'] );
			$column['date'] = $date;
		}
		return $column;
	}

	/**
	 * Add the gradebook column content
	 *
	 * @param  string $column
	 * @param  number $post_id
	 *
	 * @return mix
	 */
	function manage_course_post_column( $column, $post_id ) {
		switch ( $column ) {
			case 'gradebook':
				printf( '<a href="%s" >%s</a>',
					learn_press_gradebook_nonce_url( array( 'course_id' => $post_id ) ),
					__( 'View', 'learnpress' )
				);
				break;
		}
	}

	public static function admin_notice() {
		?>
		<div class="error">
			<p><?php printf( __( '<strong>Gradebook</strong> addon version %s requires <strong>LearnPress</strong> version %s or higher', 'learnpress' ), LP_GRADEBOOK_VER, LP_GRADEBOOK_REQUIRE_VER ); ?></p>
		</div>
		<?php
	}

	/**
	 * @return LP_GradeBook|null
	 */
	public static function instance() {
		if ( !defined( 'LEARNPRESS_VERSION' ) || ( version_compare( LEARNPRESS_VERSION, LP_GRADEBOOK_REQUIRE_VER, '<' ) ) ) {
			add_action( 'admin_notices', array( __CLASS__, 'admin_notice' ) );
			return false;
		}
		if ( !self::$_instance ) {
			self::$_instance = new self();
		}
		return self::$_instance;
	}
}

add_action( 'learn_press_loaded', array( 'LP_GradeBook', 'instance' ) );