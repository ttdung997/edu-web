;(function($){
	$(document).ready(function(){
		$('input[name="date-from"], input[name="date-to"]').datepicker();
	})
})(jQuery);