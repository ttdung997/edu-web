{{header}}

<p>Hi <strong>{{user_name}},</strong></p>

<p>You have received a certificate that certified you have passed course <a href="{{course_url}}">{{course_name}}</a></p>

<p>Please go to your profile and view it here {{user_certificate_link}}</p>

<p>Best Regards,</p>

<strong>{{site_title}}</strong>

{{footer}}