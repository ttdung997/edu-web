{{email_heading}}

Hi {{user_name}},

You have received a certificate that certified you have passed course {{course_name}}

Please go to your profile and view it here {{user_certificate_raw_link}}

Best Regards,

{{site_title}}

{{footer_text}}