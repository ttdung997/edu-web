===  LearnPress myCred - WordPress add-on for LearnPress LMS plugin ===
Contributors: thimpress, kendy73
Donate link:  
Tags: myCred, integration, point management system, lms, elearning, e-learning, learning management system, education, course, courses, quiz, quizzes, questions, training, guru, sell courses
Requires at least: 3.8  
Tested up to: 4.2.2  
Stable tag: trunk  
License: GPLv2 or later  
License URI: http://www.gnu.org/licenses/gpl-2.0.html

== Changelog ==
= 2.0.1 =
+ Changed text domain to learnpress

