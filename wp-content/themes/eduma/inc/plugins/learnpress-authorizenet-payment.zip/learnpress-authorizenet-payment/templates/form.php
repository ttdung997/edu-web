<?php
/**
 * Template for displaying Credit card payment form
 *
 * @author ThimPress
 */

defined( 'ABSPATH' ) || exit();
?>
<div id="learn-press-authorizenet-payment-form">
	<div class="row-fluid">
		<div class="span6">
			<div class="control-group">
				<label for="" class="control-label"><?php esc_html_e( 'Credit card type', 'learnpress' ) ?>
					<span style="color:#ff0000;">*</span></label>
				<div class="controls" style="margin-left:5px;">
					<select id="learn-press-authorizenet-payment-activated" name="learn-press-authorizenet-payment[activated]" disabled="disabled">
						<option value="Visa"><?php _e( 'Visa', 'learnpress' ); ?></option>
						<option value="Mastercard"><?php _e( 'Mastercard', 'learnpress' ); ?></option>
						<option value="AmericanExpress"><?php _e( 'American express', 'learnpress' ); ?></option>
						<option value="Discover"><?php _e( 'Discover', 'learnpress' ); ?></option>
						<option value="DinersClub"><?php _e( 'Diners club', 'learnpress' ); ?></option>
						<option value="JCB"><?php _e( 'Aut jcb', 'learnpress' ); ?></option>
					</select>
				</div>
			</div>
		</div>
		<div class="span6">
			<div class="control-group">
				<label for="cardexp" class="control-label"><?php _e( 'Expiration date (MM/YY)', 'learnpress' ) ?>
					<span style="color:#ff0000;">*</span></label>
				<div class="controls" style="margin-left:5px;">
					<select id="learn-press-authorizenet-payment-expmonth" name="learn-press-authorizenet-payment[expmonth]" class="inputbox required" tabindex="2" disabled="disabled">
						<option value=""><?php _e( 'Month', 'learnpress' ); ?></option>
						<option value="01"><?php _e( 'January', 'learnpress' ); ?> (01)</option>
						<option value="02"><?php _e( 'February', 'learnpress' ); ?> (02)</option>
						<option value="03"><?php _e( 'March', 'learnpress' ); ?> (03)</option>
						<option value="04"><?php _e( 'April', 'learnpress' ); ?> (04)</option>
						<option value="05"><?php _e( 'May', 'learnpress' ); ?> (05)</option>
						<option value="06"><?php _e( 'June', 'learnpress' ); ?> (06)</option>
						<option value="07"><?php _e( 'July', 'learnpress' ); ?> (07)</option>
						<option value="08"><?php _e( 'August', 'learnpress' ); ?> (08)</option>
						<option value="09"><?php _e( 'September', 'learnpress' ); ?> (09)</option>
						<option value="10"><?php _e( 'October', 'learnpress' ); ?> (10)</option>
						<option value="11"><?php _e( 'November', 'learnpress' ); ?> (11)</option>
						<option value="12"><?php _e( 'December', 'learnpress' ); ?> (12)</option>
					</select>&nbsp;
					<select id="learn-press-authorizenet-payment-expyear" name="learn-press-authorizenet-payment[expyear]" style="width:80px;" class="inputbox required" tabindex="3" disabled="disabled">
						<option value=""><?php _e( 'Year', 'learnpress' ); ?></option>
						<?php
						$expyear = date( 'Y' );
						for ( $i = date( 'Y' ); $i < ( date( 'Y' ) + 10 ); $i ++ ): ?>
							<option value="<?php esc_attr_e( $i ); ?>" <?php echo( $expyear == $i ? 'selected' : '' ); ?>><?php esc_html_e( $i ); ?></option>
							<?php
						endfor; ?>
					</select>
				</div>
			</div>
		</div>
	</div>
	<div class="row-fluid">
		<div class="span6">
			<div class="control-group">
				<label for="cardnum" class="control-label"><?php _e( 'Card number', 'learnpress' ) ?>
					<span style="color:#ff0000;">*</span></label>
				<div class="controls" style="margin-left:5px;">
					<input class="inputbox required" id="learn-press-authorizenet-payment-cardnum" type="text" name="learn-press-authorizenet-payment[cardnum]" tabindex="4" size="35" style="width:190px;" value="" disabled="disabled" />
				</div>
			</div>
		</div>
		<div class="span6">
			<div class="control-group">
				<label for="cardcvv" class="control-label"><?php _e( 'Card cvv number', 'learnpress' ) ?>
					<span style="color:#ff0000;">*</span></label>
				<div class="controls" style="margin-left:5px;">
					<input class="inputbox required" id="learn-press-authorizenet-payment-cardcvv" type="text" name="learn-press-authorizenet-payment[cardcvv]" tabindex="5" maxlength="5" size="10" style="width:50px;" value="" disabled="disabled" />
				</div>
			</div>
		</div>
	</div>
</div>
