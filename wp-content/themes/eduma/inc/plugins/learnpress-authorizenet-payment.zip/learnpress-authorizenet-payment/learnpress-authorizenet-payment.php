<?php
/*
Plugin Name: LearnPress - Authorize.net Payment
Plugin URI: http://thimpress.com/
Description: Payment Authorize.net for LearnPress
Author: ThimPress
Version: 2.0
Author URI: http://thimpress.com
Tags: learnpress, lms
Text Domain: learnpress
Domain Path: /languages/
*/

if ( !defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}
define( 'LP_ADDON_AUTHORIZENET_PAYMENT_FILE', __FILE__ );
define( 'LP_ADDON_AUTHORIZENET_PAYMENT_PATH', dirname( __FILE__ ) );
define( 'LP_ADDON_AUTHORIZENET_PAYMENT_TMPL', LP_ADDON_AUTHORIZENET_PAYMENT_PATH . '/templates/' );
function learn_press_register_authorizenet_payment() {
	require_once( LP_ADDON_AUTHORIZENET_PAYMENT_PATH . '/incs/class-lp-authorizenet-payment-gateways.php' );
}

add_action( 'learn_press_loaded', 'learn_press_register_authorizenet_payment' );
