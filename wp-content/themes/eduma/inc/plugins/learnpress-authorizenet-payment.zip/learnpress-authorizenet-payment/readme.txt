=== LearnPress - Authorize.net Payment ===
Contributors: thimpress, phonglq
Donate link:
Tags: lms, authorize, payment, learnpress, elearning, e-learning, learning management system, education, course, courses, quiz, quizzes, questions, training, guru, sell courses
Requires at least: 3.8
Tested up to: 4.6.1
Stable tag: 1.0
License: GPLv3
License URI: https://www.gnu.org/licenses/gpl-3.0.html

== Description ==

Makes LearnPress plugin ready to use Authorize.net payment gateway to pay for courses

== Required ==

You must have a Authorize.net account

== Installation ==

1. Download Authorizenet payment Plugin to your desktop.
2. If downloaded as a zip archive, extract the Plugin folder to your desktop.
3. With your FTP program, upload the Plugin folder to the wp-content/plugins folder in your WordPress directory online.
4. Go to Plugins screen and find the newly uploaded Plugin in the list.
5. Click Activate to activate it.

== Configuration ==

1. Go to the Setting page of LearnPress plugin by click the left menu Settings/LearnPress
2. Click to Payments tab then click "Authorize.net" link
3. Fill fields "Authorize.net Login Id", "Authorize.net Transaction Key" and mark "Enable" checkbox as checked
4. Press the "Save setting" button to store configurations.

== Changelog ==
= 2.0 =
+ Changed text domain to learnpress

= 1.0 =
+ The first beta release.