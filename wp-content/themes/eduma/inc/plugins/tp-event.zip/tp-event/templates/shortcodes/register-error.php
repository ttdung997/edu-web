<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit();
}
?>
<ul class="tp-event-notice error">
    <li><?php _e( 'Oops! Something went wrong.' ) ?></li>
</ul>