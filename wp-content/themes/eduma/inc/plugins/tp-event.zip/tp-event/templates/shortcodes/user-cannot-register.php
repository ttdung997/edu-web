<?php
if ( !defined( 'ABSPATH' ) ) {
    exit;
}
?>

<p><?php _e( 'User registration is currently not allowed.', 'tp-event' ) ?></p>