=== LearnPress - Random Quiz ===
Contributors: thimpress, tunnhn
Donate link:  
Tags: lms, elearning, e-learning, learning management system, education, course, courses, quiz, quizzes, questions, training, guru, sell courses  
Requires at least: 3.8  
Tested up to: 4.6.1  
Stable tag: 2.0
License: GPLv2 or later  
License URI: http://www.gnu.org/licenses/gpl-2.0.html  

Random Quiz addon for LearnPress - WordPress LMS Plugin.

== Description ==  

== Installation ==  

**From your WordPress dashboard**    
1. Visit 'Plugin > Add new'.  
2. Search for 'LearnPress bbPress'.    
3. Activate LearnPress from your Plugins page.  

== Changelog ==
= 2.1.0 =
+ Changed text domain to learnpress

= 2.0 =
+ Updated to be compatible with LearnPress 2.0
