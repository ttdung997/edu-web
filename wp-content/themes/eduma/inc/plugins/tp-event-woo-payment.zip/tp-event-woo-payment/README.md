# tp-event-woo-payment
Add the payment system provided by WooCommerce for TP Events plugin
