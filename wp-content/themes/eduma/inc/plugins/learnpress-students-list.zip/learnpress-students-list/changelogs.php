= 2.0.1 =
+ Changed text domain to learnpress.