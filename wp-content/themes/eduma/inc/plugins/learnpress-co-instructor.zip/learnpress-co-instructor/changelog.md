**Version 1.2.4**
- Add function send mail for co-instructors of course when this course is enrolled
**Version 1.2.3**
- Don't duplicate instructors in course
**Version 1.2.2**
- Create tab instructor in profile
- Allow co-instructor and admin: add, create and edit item (lesson, quiz, question) of course.